package ftp_application;

import java.sql.Connection;
import java.sql.DriverManager;

public final class Connect {
	private Connection conn;
	 public Connect(){
	  conn = null;
	  try{
	   String userName = "root";
	   String password = "";
	   String url = "jdbc:mysql://localhost/root";
	   Class.forName ("com.mysql.jdbc.Driver").newInstance ();
	   conn = DriverManager.getConnection(url, userName, password);
	  }
	  catch(Exception e){
	   System.out.println("Exception found");
	  }
	 }
	 public Connection getConnection(){
	  return conn;
	 }
	 public void closeConnection(){
	  try{
	   conn.close ();
	  }catch (Exception e) {
	   System.out.println ("Connection close error");
	  }
	 }
}

	//The code below is the main part in connecting to the database.


	String userName = "root";
	String password = "";
	String url = "jdbc:mysql://localhost/root";
	Class.forName ("com.mysql.jdbc.Driver").newInstance ();
	conn = DriverManager.getConnection(url, userName, password);

	}
